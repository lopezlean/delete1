<?php return array('dependencies' => array('wp-i18n'), 'version' => 'a5d3fc78512d6cb588af');

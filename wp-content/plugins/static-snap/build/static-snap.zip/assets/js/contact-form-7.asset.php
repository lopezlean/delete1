<?php return array('dependencies' => array('wp-i18n'), 'version' => '6a06ac157e253cdb46a3');

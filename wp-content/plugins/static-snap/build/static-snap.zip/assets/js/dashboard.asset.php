<?php return array('dependencies' => array('lodash', 'react', 'react-dom', 'wp-api-fetch', 'wp-i18n', 'wp-url'), 'version' => '8ad8357d0a93478a1ad2');

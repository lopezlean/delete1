<?php return array('dependencies' => array('wp-i18n'), 'version' => '80d837b667c2b60c61c6');

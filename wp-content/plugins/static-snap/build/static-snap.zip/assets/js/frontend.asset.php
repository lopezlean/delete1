<?php return array('dependencies' => array('wp-i18n'), 'version' => '1c7741501d422b5e816b');

<?php return array('dependencies' => array(), 'version' => '1743b7d7649db335eb84');

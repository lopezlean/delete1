<?php return array('dependencies' => array('wp-i18n'), 'version' => 'af2030d83c7e18ddbfdb');

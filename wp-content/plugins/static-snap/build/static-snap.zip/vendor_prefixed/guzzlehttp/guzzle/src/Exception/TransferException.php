<?php

namespace StaticSnapVendor\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException
{
}

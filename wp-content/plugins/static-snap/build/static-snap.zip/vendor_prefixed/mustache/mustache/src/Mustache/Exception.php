<?php

namespace StaticSnapVendor;

/*
 * This file is part of Mustache.php.
 *
 * (c) 2010-2017 Justin Hileman
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
/**
 * A Mustache Exception interface.
 */
interface Mustache_Exception
{
    // This space intentionally left blank.
}
/*
 * This file is part of Mustache.php.
 *
 * (c) 2010-2017 Justin Hileman
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
/**
 * A Mustache Exception interface.
 */
\class_alias('StaticSnapVendor\\Mustache_Exception', 'Mustache_Exception', \false);

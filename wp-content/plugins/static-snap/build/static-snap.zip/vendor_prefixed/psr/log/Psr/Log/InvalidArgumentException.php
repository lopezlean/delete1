<?php

namespace StaticSnapVendor\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}

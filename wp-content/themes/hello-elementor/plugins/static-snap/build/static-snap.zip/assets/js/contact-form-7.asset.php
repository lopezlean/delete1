<?php return array('dependencies' => array(), 'version' => '09d69513e01d45a2b8e1');

<?php return array('dependencies' => array('lodash', 'react', 'react-dom', 'wp-api-fetch', 'wp-i18n', 'wp-url'), 'version' => '59455bdd0efcbc90c607');

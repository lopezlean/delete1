<?php return array('dependencies' => array(), 'version' => 'c2726883aa3d9c9c7c6d');

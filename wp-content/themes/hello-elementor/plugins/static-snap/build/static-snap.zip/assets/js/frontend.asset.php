<?php return array('dependencies' => array('wp-i18n'), 'version' => '90ce0f4e61f72a62663c');

<?php return array('dependencies' => array(), 'version' => '391424632d17a58b3881');

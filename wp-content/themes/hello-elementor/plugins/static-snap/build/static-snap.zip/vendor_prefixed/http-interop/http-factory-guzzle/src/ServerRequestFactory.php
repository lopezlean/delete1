<?php

namespace StaticSnapVendor\Http\Factory\Guzzle;

use StaticSnapVendor\GuzzleHttp\Psr7\ServerRequest;
use StaticSnapVendor\Psr\Http\Message\ServerRequestFactoryInterface;
use StaticSnapVendor\Psr\Http\Message\ServerRequestInterface;
class ServerRequestFactory implements ServerRequestFactoryInterface
{
    public function createServerRequest(string $method, $uri, array $serverParams = []) : ServerRequestInterface
    {
        if (empty($method)) {
            if (!empty($serverParams['REQUEST_METHOD'])) {
                $method = $serverParams['REQUEST_METHOD'];
            } else {
                throw new \InvalidArgumentException('Cannot determine HTTP method');
            }
        }
        return new ServerRequest($method, $uri, [], null, '1.1', $serverParams);
    }
}

<?php

namespace StaticSnapVendor\Github\Exception;

/**
 * @author Joseph Bielawski <stloyd@gmail.com>
 */
class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}

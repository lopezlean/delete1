<?php

namespace StaticSnapVendor\Github\HttpClient\Plugin;

use StaticSnapVendor\Http\Client\Common\Plugin\Journal;
use StaticSnapVendor\Psr\Http\Client\ClientExceptionInterface;
use StaticSnapVendor\Psr\Http\Message\RequestInterface;
use StaticSnapVendor\Psr\Http\Message\ResponseInterface;
/**
 * A plugin to remember the last response.
 *
 * @author Tobias Nyholm <tobias.nyholm@gmail.com>
 */
final class History implements Journal
{
    /**
     * @var ResponseInterface|null
     */
    private $lastResponse;
    /**
     * @return ResponseInterface|null
     */
    public function getLastResponse() : ?ResponseInterface
    {
        return $this->lastResponse;
    }
    /**
     * @return void
     */
    public function addSuccess(RequestInterface $request, ResponseInterface $response) : void
    {
        $this->lastResponse = $response;
    }
    /**
     * @return void
     */
    public function addFailure(RequestInterface $request, ClientExceptionInterface $exception) : void
    {
    }
}

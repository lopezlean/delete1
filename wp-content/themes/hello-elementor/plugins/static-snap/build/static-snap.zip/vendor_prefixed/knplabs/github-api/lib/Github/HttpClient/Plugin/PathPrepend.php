<?php

namespace StaticSnapVendor\Github\HttpClient\Plugin;

use StaticSnapVendor\Http\Client\Common\Plugin;
use StaticSnapVendor\Http\Promise\Promise;
use StaticSnapVendor\Psr\Http\Message\RequestInterface;
/**
 * Prepend the URI with a string.
 *
 * @author Tobias Nyholm <tobias.nyholm@gmail.com>
 */
final class PathPrepend implements Plugin
{
    /**
     * @var string
     */
    private $path;
    /**
     * @param string $path
     */
    public function __construct(string $path)
    {
        $this->path = $path;
    }
    /**
     * @param RequestInterface $request
     * @param callable         $next
     * @param callable         $first
     *
     * @return Promise
     */
    public function handleRequest(RequestInterface $request, callable $next, callable $first) : Promise
    {
        $currentPath = $request->getUri()->getPath();
        if (\strpos($currentPath, $this->path) !== 0) {
            $uri = $request->getUri()->withPath($this->path . $currentPath);
            $request = $request->withUri($uri);
        }
        return $next($request);
    }
}

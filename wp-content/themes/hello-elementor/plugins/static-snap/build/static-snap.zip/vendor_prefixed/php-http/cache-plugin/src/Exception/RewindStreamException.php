<?php

namespace StaticSnapVendor\Http\Client\Common\Plugin\Exception;

use StaticSnapVendor\Http\Client\Exception;
/**
 * @author Théo FIDRY <theo.fidry@gmail.com>
 */
class RewindStreamException extends \RuntimeException implements Exception
{
}

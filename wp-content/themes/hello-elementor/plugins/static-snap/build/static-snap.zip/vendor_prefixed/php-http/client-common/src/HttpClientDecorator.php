<?php

declare (strict_types=1);
namespace StaticSnapVendor\Http\Client\Common;

use StaticSnapVendor\Psr\Http\Client\ClientInterface;
use StaticSnapVendor\Psr\Http\Message\RequestInterface;
use StaticSnapVendor\Psr\Http\Message\ResponseInterface;
/**
 * Decorates an HTTP Client.
 *
 * @author Márk Sági-Kazár <mark.sagikazar@gmail.com>
 */
trait HttpClientDecorator
{
    /**
     * @var ClientInterface
     */
    protected $httpClient;
    /**
     * {@inheritdoc}
     *
     * @see ClientInterface::sendRequest
     */
    public function sendRequest(RequestInterface $request) : ResponseInterface
    {
        return $this->httpClient->sendRequest($request);
    }
}
